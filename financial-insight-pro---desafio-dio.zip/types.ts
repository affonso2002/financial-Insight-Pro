
export type CategoryType = 'Segment' | 'Country' | 'Product' | 'Discount Band';
export type MeasureType = 'Sales' | 'Profit' | 'Units Sold' | 'Gross Sales' | 'COGS';

export interface FinancialRecord {
  Segment: string;
  Country: string;
  Product: string;
  'Discount Band': string;
  'Units Sold': number;
  'Manufacturing Price': number;
  'Sale Price': number;
  'Gross Sales': number;
  Discounts: number;
  Sales: number;
  COGS: number;
  Profit: number;
  Date: string;
}

export interface ChartDataItem {
  name: string;
  value: number;
}

export interface InsightResponse {
  analysis: string;
  recommendations: string[];
}
