
import { GoogleGenAI, Type } from "@google/genai";
import { CategoryType, MeasureType, ChartDataItem } from "../types";

// Always use the API key directly from process.env.API_KEY as per guidelines.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getFinancialInsights(
  category: CategoryType,
  measure: MeasureType,
  data: ChartDataItem[]
): Promise<{ analysis: string; recommendations: string[] }> {
  try {
    const dataContext = data.map(d => `${d.name}: ${d.value}`).join(', ');
    const prompt = `Analyze the financial data of a fictional company.
    Currently viewing the metric "${measure}" grouped by the category "${category}".
    Data Points: [${dataContext}].
    
    Create a professional executive summary in English for a boardroom presentation.
    Focus on storytelling: What do these numbers mean for the business? 
    Which category is performing best relative to ${measure}? 
    Are there any points of concern or trends?
    
    Provide a detailed textual analysis and 3 actionable strategic recommendations.`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            analysis: { type: Type.STRING, description: "A detailed analysis in paragraph format." },
            recommendations: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "A list of 3 strategic recommendations."
            }
          },
          required: ["analysis", "recommendations"]
        }
      }
    });

    // Access the generated text using the .text property (not a method) and trim whitespace.
    const jsonStr = response.text.trim();
    return JSON.parse(jsonStr);
  } catch (error) {
    console.error("Error fetching insights:", error);
    return {
      analysis: "Currently unable to generate automated analysis due to an AI service connection issue.",
      recommendations: ["Check your internet connection", "Try again later", "Consult technical support"]
    };
  }
}
