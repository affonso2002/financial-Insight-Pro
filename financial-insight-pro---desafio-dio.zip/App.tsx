
import React, { useState, useMemo, useEffect } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  Legend
} from 'recharts';
import { MOCK_DATA } from './constants';
import { CategoryType, MeasureType, ChartDataItem, InsightResponse } from './types';
import { getFinancialInsights } from './services/geminiService';
import SummaryCard from './components/SummaryCard';

// Professional Blue & Green Palette
const COLORS = [
  '#6366f1', // Indigo 500
  '#10b981', // Emerald 500
  '#3b82f6', // Blue 500
  '#14b8a6', // Teal 500
  '#818cf8', // Indigo 400
  '#34d399', // Emerald 400
  '#60a5fa', // Blue 400
  '#2dd4bf', // Teal 400
];

const App: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<CategoryType>('Segment');
  const [selectedMeasure, setSelectedMeasure] = useState<MeasureType>('Sales');
  const [insight, setInsight] = useState<InsightResponse | null>(null);
  const [loadingInsight, setLoadingInsight] = useState(false);
  const [fullScreenChart, setFullScreenChart] = useState<'bar' | 'ranking' | null>(null);
  const [hiddenItems, setHiddenItems] = useState<string[]>([]);

  const categories: CategoryType[] = ['Segment', 'Country', 'Product', 'Discount Band'];
  const measures: MeasureType[] = ['Sales', 'Profit', 'Units Sold', 'Gross Sales', 'COGS'];

  const chartData = useMemo(() => {
    const aggMap = MOCK_DATA.reduce((acc, curr) => {
      const key = curr[selectedCategory] as string;
      const val = curr[selectedMeasure] as number;
      acc[key] = (acc[key] || 0) + val;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(aggMap).map(([name, value]) => ({ name, value }));
  }, [selectedCategory, selectedMeasure]);

  useEffect(() => {
    setHiddenItems([]);
  }, [selectedCategory]);

  const filteredChartData = useMemo(() => {
    return chartData
      .filter(item => !hiddenItems.includes(item.name))
      .sort((a, b) => b.value - a.value);
  }, [chartData, hiddenItems]);

  const totalMeasure = useMemo(() => {
    return filteredChartData.reduce((sum, item) => sum + item.value, 0);
  }, [filteredChartData]);

  const averageMeasure = useMemo(() => {
    return filteredChartData.length > 0 ? totalMeasure / filteredChartData.length : 0;
  }, [totalMeasure, filteredChartData]);

  const topPerformer = useMemo(() => {
    if (filteredChartData.length === 0) return null;
    return filteredChartData[0];
  }, [filteredChartData]);

  const fetchAIInsights = async () => {
    setLoadingInsight(true);
    const result = await getFinancialInsights(selectedCategory, selectedMeasure, chartData);
    setInsight(result);
    setLoadingInsight(false);
  };

  useEffect(() => {
    fetchAIInsights();
  }, [selectedCategory, selectedMeasure]);

  const formatCurrency = (val: number) => {
    if (selectedMeasure === 'Units Sold') return val.toLocaleString('en-US');
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(val);
  };

  const handleExportCSV = () => {
    const now = new Date().toLocaleString('en-US');
    let csvContent = "\uFEFF";
    csvContent += `EXECUTIVE REPORT - FINANALYTICS\n`;
    csvContent += `Exported at: ${now}\n`;
    csvContent += `Dimension: ${selectedCategory}\n`;
    csvContent += `Metric: ${selectedMeasure}\n`;
    csvContent += `------------------------------------\n\n`;
    
    const headers = [selectedCategory, selectedMeasure];
    csvContent += headers.join(',') + '\n';
    
    filteredChartData.forEach(item => {
      csvContent += `"${item.name}",${item.value}\n`;
    });
    
    csvContent += `\n------------------------------------\n`;
    csvContent += `VISIBLE DATA SUMMARY\n`;
    csvContent += `Total ${selectedMeasure},${totalMeasure}\n`;
    csvContent += `Average,${averageMeasure.toFixed(2)}\n`;
    csvContent += `Top Performer,${topPerformer?.name || 'N/A'}\n`;

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `financial_report_${selectedCategory.toLowerCase()}_${selectedMeasure.toLowerCase()}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const toggleVisibility = (name: string) => {
    setHiddenItems(prev => 
      prev.includes(name) ? prev.filter(i => i !== name) : [...prev, name]
    );
  };

  const renderLegend = () => {
    const fullPayload = chartData.map((item, index) => ({
      value: item.name,
      id: item.name,
      color: COLORS[index % COLORS.length]
    }));

    return (
      <ul className="flex flex-wrap justify-center gap-x-8 gap-y-3 mt-8 px-4 list-none">
        {fullPayload.map((entry, index) => {
          const isHidden = hiddenItems.includes(entry.value);
          return (
            <li
              key={`legend-item-${index}`}
              className="group flex items-center gap-3 cursor-pointer select-none transition-all duration-200"
              onClick={() => toggleVisibility(entry.value)}
            >
              <div 
                className={`w-4 h-4 rounded-full transition-all duration-300 ${isHidden ? 'bg-slate-700 scale-75' : 'group-hover:scale-125'}`}
                style={{ backgroundColor: isHidden ? undefined : entry.color }}
              />
              <span className={`text-sm font-bold transition-colors duration-300 text-white ${isHidden ? 'opacity-40 line-through' : ''}`}>
                {entry.value}
              </span>
            </li>
          );
        })}
      </ul>
    );
  };

  const renderBarChart = (isFullScreen = false) => (
    <ResponsiveContainer 
      width="100%" 
      height="100%" 
      key={`bar-${selectedCategory}-${selectedMeasure}-${isFullScreen}-${hiddenItems.join(',')}`}
    >
      <BarChart data={filteredChartData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#334155" />
        <XAxis dataKey="name" axisLine={false} tick={false} />
        <YAxis 
          axisLine={false} 
          tickLine={false} 
          tick={{ fill: '#ffffff', fontSize: 14 }} 
          tickFormatter={(value) => value > 1000 ? `${(value/1000).toFixed(0)}k` : value}
        />
        <Tooltip 
          cursor={{ fill: '#1e293b', fillOpacity: 0.4 }}
          contentStyle={{ backgroundColor: '#1e293b', borderRadius: '12px', border: '1px solid #334155', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.5)', padding: '16px' }}
          itemStyle={{ fontWeight: 'bold', fontSize: '16px', color: '#ffffff' }}
          labelStyle={{ color: '#ffffff', marginBottom: '6px', fontSize: '14px' }}
          formatter={(value: number) => [formatCurrency(value), selectedMeasure]}
        />
        <Bar 
          dataKey="value" 
          radius={[4, 4, 0, 0]} 
          barSize={isFullScreen ? 70 : 50}
          isAnimationActive={true}
        >
          {filteredChartData.map((entry, index) => {
            const originalIndex = chartData.findIndex(item => item.name === entry.name);
            return (
              <Cell 
                key={`cell-${index}`} 
                fill={COLORS[originalIndex % COLORS.length]} 
                fillOpacity={0.8}
                className="hover:fill-opacity-100 transition-all duration-300"
              />
            );
          })}
        </Bar>
        <Legend content={renderLegend} verticalAlign="bottom" height={80} />
      </BarChart>
    </ResponsiveContainer>
  );

  const renderRankingChart = (isFullScreen = false) => (
    <ResponsiveContainer 
      width="100%" 
      height="100%" 
      key={`ranking-${selectedCategory}-${selectedMeasure}-${isFullScreen}-${hiddenItems.join(',')}`}
    >
      <BarChart 
        layout="vertical" 
        data={filteredChartData} 
        margin={{ top: 10, right: 60, left: isFullScreen ? 140 : 120, bottom: 10 }}
      >
        <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#334155" />
        <XAxis 
          type="number" 
          axisLine={false} 
          tickLine={false} 
          tick={{ fill: '#ffffff', fontSize: 12 }} 
          tickFormatter={(value) => value > 1000 ? `${(value/1000).toFixed(0)}k` : value}
        />
        <YAxis 
          type="category" 
          dataKey="name" 
          axisLine={false} 
          tickLine={false} 
          tick={{ fill: '#ffffff', fontSize: 13, fontWeight: 'bold' }} 
          width={isFullScreen ? 140 : 120}
        />
        <Tooltip 
          cursor={{ fill: '#1e293b', fillOpacity: 0.4 }}
          contentStyle={{ backgroundColor: '#1e293b', borderRadius: '12px', border: '1px solid #334155', padding: '16px' }}
          itemStyle={{ fontWeight: 'bold', fontSize: '16px', color: '#ffffff' }}
          formatter={(value: number) => {
            const percent = ((value / (totalMeasure || 1)) * 100).toFixed(1);
            return [`${formatCurrency(value)} (${percent}%)`, selectedMeasure];
          }}
        />
        <Bar 
          dataKey="value" 
          radius={[0, 4, 4, 0]} 
          barSize={isFullScreen ? 45 : 30}
        >
          {filteredChartData.map((entry, index) => {
            const originalIndex = chartData.findIndex(item => item.name === entry.name);
            return (
              <Cell 
                key={`cell-ranking-${index}`} 
                fill={COLORS[originalIndex % COLORS.length]} 
                fillOpacity={0.8}
                className="hover:fill-opacity-100 transition-all duration-300"
              />
            );
          })}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-[#0f172a] text-white text-lg">
      <aside className="w-full lg:w-80 bg-[#1e293b] border-r border-slate-800 p-8 flex flex-col gap-10 shadow-2xl lg:sticky lg:top-0 lg:h-screen">
        <div className="relative group">
          <div className="absolute -inset-1 bg-emerald-500/20 rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
          <div className="relative px-6 py-8 bg-[#0f172a]/50 border border-slate-700/50 rounded-2xl backdrop-blur-sm">
            <h1 className="text-4xl font-black text-white flex items-center gap-3 italic tracking-tighter">
              <i className="fa-solid fa-chart-line text-emerald-400"></i>
              FinAnalytics
            </h1>
            <div className="flex items-center gap-3 mt-3">
              <span className="text-xs text-white font-black uppercase tracking-[0.2em]">Insights Portal</span>
              <span className="flex h-2.5 w-2.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-400"></span>
              </span>
              <span className="text-[10px] bg-emerald-500 text-slate-900 px-2 py-0.5 rounded border border-emerald-400 font-black uppercase">PRO</span>
            </div>
          </div>
        </div>

        <nav className="flex flex-col gap-10">
          <section>
            <label className="block text-xs font-black text-white mb-6 uppercase tracking-widest flex items-center gap-2">
              <i className="fa-solid fa-layer-group text-emerald-400"></i>
              Analysis Dimension
            </label>
            <div className="flex flex-col gap-2">
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-6 py-4 rounded-xl text-base font-bold transition-all text-left border-2 ${
                    selectedCategory === cat 
                    ? 'bg-emerald-500/20 text-white border-emerald-500/50 shadow-[0_0_20px_rgba(16,185,129,0.2)]' 
                    : 'text-white border-transparent hover:bg-slate-800'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </section>

          <section>
            <label className="block text-xs font-black text-white mb-6 uppercase tracking-widest flex items-center gap-2">
              <i className="fa-solid fa-coins text-teal-400"></i>
              Value Metric
            </label>
            <div className="flex flex-col gap-2">
              {measures.map(m => (
                <button
                  key={m}
                  onClick={() => setSelectedMeasure(m)}
                  className={`px-6 py-4 rounded-xl text-base font-bold transition-all text-left border-2 ${
                    selectedMeasure === m 
                    ? 'bg-emerald-500/20 text-white border-emerald-500/50 shadow-[0_0_20px_rgba(16,185,129,0.2)]' 
                    : 'text-white border-transparent hover:bg-slate-800'
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>
          </section>
        </nav>

        <div className="mt-auto pt-8 border-t border-slate-800">
          <p className="text-xs text-white leading-tight font-black uppercase tracking-tighter italic">
            Strategic Logic Dashboard
          </p>
        </div>
      </aside>

      <main className="flex-1 p-8 lg:p-14 overflow-auto relative">
        <div className="absolute top-10 right-10 text-[12rem] font-black text-white/5 pointer-events-none select-none tracking-tighter">
          EXECUTIVE
        </div>

        <header className="mb-20 flex flex-col md:flex-row justify-between items-start md:items-end gap-10 relative z-10">
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-4">
              <div className="h-12 w-2 bg-emerald-400 rounded-full shadow-[0_0_15px_rgba(52,211,153,0.5)]"></div>
              <h2 className="text-6xl lg:text-8xl font-black tracking-tighter text-white drop-shadow-sm">
                Executive Summary
              </h2>
            </div>
            <p className="text-white text-xl font-bold max-w-3xl ml-6">
              Strategic performance indicators and real-time dimension analysis for <span className="text-white border-b-4 border-emerald-500/50 pb-1">{selectedCategory.toLowerCase()}</span>.
            </p>
          </div>
          <div className="flex gap-4 mb-2">
            <button 
              onClick={handleExportCSV}
              className="px-8 py-4 bg-[#1e293b] border border-white/20 rounded-2xl text-sm font-bold text-white hover:bg-slate-800 transition-all flex items-center gap-3 shadow-lg"
            >
              <i className="fa-solid fa-file-csv text-emerald-400"></i> Export Dataset
            </button>
            <button 
              onClick={fetchAIInsights}
              disabled={loadingInsight}
              className="px-8 py-4 bg-white text-slate-900 rounded-2xl text-sm font-black hover:bg-emerald-50 transition-all shadow-xl flex items-center gap-3 disabled:opacity-50"
            >
              <i className={`fa-solid ${loadingInsight ? 'fa-spinner fa-spin' : 'fa-wand-magic-sparkles'} text-emerald-600`}></i>
              Generate New Insights
            </button>
          </div>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          <SummaryCard 
            label={`Total ${selectedMeasure}`} 
            value={formatCurrency(totalMeasure)} 
            icon="fa-money-bill-trend-up" 
            colorClass="text-emerald-400"
          />
          <SummaryCard 
            label="Metric Average" 
            value={formatCurrency(averageMeasure)} 
            icon="fa-scale-balanced" 
            colorClass="text-teal-400"
          />
          <SummaryCard 
            label={`Top ${selectedCategory}`} 
            value={topPerformer?.name || 'N/A'} 
            icon="fa-trophy" 
            colorClass="text-green-400"
          />
          <SummaryCard 
            label="Dominance Share" 
            value={totalMeasure > 0 ? `${((topPerformer?.value / totalMeasure) * 100).toFixed(1)}%` : '0%'} 
            icon="fa-percent" 
            colorClass="text-emerald-300"
          />
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-10">
          <div className="xl:col-span-2 bg-[#1e293b] p-10 rounded-[3rem] shadow-2xl border border-white/10 relative overflow-hidden group">
            <div className="flex justify-between items-center mb-12">
              <div className="flex flex-col gap-2">
                <h3 className="font-black text-white text-3xl tracking-tight">Performance Volume</h3>
                <span className="text-xs text-white font-black uppercase tracking-widest">Comparative distribution by {selectedCategory}</span>
              </div>
              <button 
                onClick={() => setFullScreenChart('bar')}
                className="text-white hover:bg-slate-800 transition-colors p-4 rounded-2xl border border-white/10"
              >
                <i className="fa-solid fa-expand text-xl text-emerald-400"></i>
              </button>
            </div>
            <div className="h-[550px]">
              {renderBarChart()}
            </div>
          </div>

          <div className="bg-[#1e293b] p-10 rounded-[3rem] shadow-2xl border border-white/10 flex flex-col group relative overflow-hidden">
            <div className="flex justify-between items-center mb-12">
              <div className="flex flex-col gap-2">
                <h3 className="font-black text-white text-3xl tracking-tight">Driver Ranking</h3>
                <span className="text-xs text-white font-black uppercase tracking-widest">Ordered significance scale</span>
              </div>
              <button 
                onClick={() => setFullScreenChart('ranking')}
                className="text-white hover:bg-slate-800 transition-colors p-4 rounded-2xl border border-white/10"
              >
                <i className="fa-solid fa-expand text-xl text-teal-400"></i>
              </button>
            </div>
            <div className="h-[550px] flex-grow">
              {renderRankingChart()}
            </div>
            <div className="mt-10 p-8 bg-slate-900/60 rounded-[2rem] border border-white/10">
              <p className="text-xs text-white font-black italic leading-relaxed uppercase tracking-wider">
                <i className="fa-solid fa-circle-info mr-2 text-emerald-500"></i>
                Ranking analysis isolated for decision making.
              </p>
            </div>
          </div>
        </div>

        {fullScreenChart && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-8 bg-[#0f172a]/98 backdrop-blur-3xl animate-in fade-in duration-300">
            <div className="bg-[#1e293b] w-full h-full rounded-[4rem] shadow-[0_0_100px_rgba(0,0,0,0.8)] overflow-hidden flex flex-col p-16 relative border border-white/30 text-white">
              <button 
                onClick={() => setFullScreenChart(null)}
                className="absolute top-12 right-12 w-16 h-16 flex items-center justify-center bg-white text-slate-900 rounded-[2rem] transition-all shadow-2xl hover:scale-105"
              >
                <i className="fa-solid fa-xmark text-3xl"></i>
              </button>

              <div className="mb-14">
                <h3 className="text-6xl font-black text-white tracking-tighter mb-6">
                  {fullScreenChart === 'bar' 
                    ? `Detailed Volume Distribution` 
                    : `Comprehensive Ranking Perspective`}
                </h3>
                <div className="flex items-center gap-10">
                  <span className="text-white text-2xl font-black">Metric: <span className="underline decoration-emerald-500">{selectedMeasure}</span></span>
                  <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                  <span className="text-white text-2xl font-black">Dimension: <span className="underline decoration-teal-500">{selectedCategory}</span></span>
                </div>
              </div>

              <div className="flex-1 min-h-0">
                {fullScreenChart === 'bar' ? renderBarChart(true) : renderRankingChart(true)}
              </div>

              <div className="mt-14 flex justify-between items-center border-t border-white/20 pt-12">
                <div className="flex gap-20">
                  <div className="text-base">
                    <span className="text-white block uppercase tracking-[0.2em] text-xs font-black mb-3">Aggregate Result</span>
                    <span className="font-black text-white text-5xl tracking-tighter">{formatCurrency(totalMeasure)}</span>
                  </div>
                  <div className="text-base">
                    <span className="text-white block uppercase tracking-[0.2em] text-xs font-black mb-3">Market Leader</span>
                    <span className="font-black text-white text-5xl tracking-tighter uppercase">{topPerformer?.name || 'N/A'}</span>
                  </div>
                </div>
                <button 
                  onClick={handleExportCSV}
                  className="px-12 py-6 bg-white text-slate-900 rounded-[2rem] text-base font-black hover:bg-slate-100 transition-all shadow-2xl flex items-center gap-4"
                >
                  <i className="fa-solid fa-download text-emerald-600"></i> Download Audit Data (CSV)
                </button>
              </div>
            </div>
          </div>
        )}

        <section className="mt-20">
          <div className="bg-gradient-to-br from-slate-800 via-slate-900 to-black rounded-[4rem] p-16 text-white shadow-2xl border border-white/10 relative overflow-hidden group">
            <div className="relative z-10">
              <div className="flex items-center gap-8 mb-16">
                <span className="bg-[#1e293b] p-6 rounded-[2.5rem] border border-emerald-500/30 shadow-inner">
                  <i className="fa-solid fa-brain text-5xl text-emerald-400"></i>
                </span>
                <div>
                  <h3 className="text-5xl font-black tracking-tighter text-white">AI Executive Intelligence</h3>
                  <p className="text-white text-base font-black uppercase tracking-[0.3em] mt-2">Strategic Logic Engine v3.1</p>
                </div>
              </div>

              {loadingInsight ? (
                <div className="space-y-10 animate-pulse">
                  <div className="h-8 bg-white/10 rounded-full w-3/4"></div>
                  <div className="h-8 bg-white/10 rounded-full w-full"></div>
                  <div className="pt-14 grid grid-cols-1 md:grid-cols-3 gap-10">
                     <div className="h-48 bg-white/5 rounded-[2.5rem]"></div>
                     <div className="h-48 bg-white/5 rounded-[2.5rem]"></div>
                     <div className="h-48 bg-white/5 rounded-[2.5rem]"></div>
                  </div>
                </div>
              ) : insight ? (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-20">
                  <div className="lg:col-span-7">
                    <p className="text-3xl leading-relaxed font-bold text-white tracking-tight first-letter:text-8xl first-letter:font-black first-letter:text-emerald-400 first-letter:mr-6 first-letter:float-left first-letter:leading-[0.8]">
                      {insight.analysis}
                    </p>
                  </div>
                  <div className="lg:col-span-5">
                    <h4 className="font-black text-white text-sm uppercase tracking-[0.3em] mb-10 flex items-center gap-4">
                      <i className="fa-solid fa-bolt-lightning text-teal-400"></i>
                      Strategic Directives
                    </h4>
                    <div className="space-y-8">
                      {insight.recommendations.map((rec, i) => (
                        <div key={i} className="flex gap-8 bg-white/5 p-8 rounded-[2rem] border border-white/10 backdrop-blur-md transition-all hover:bg-white/10 group/rec">
                          <span className="text-emerald-400 font-black text-3xl group-hover/rec:scale-110 transition-transform">0{i+1}</span>
                          <p className="text-lg font-black text-white leading-snug tracking-tight">{rec}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-24 border-2 border-dashed border-white/10 rounded-[3rem]">
                  <p className="text-white font-black text-2xl uppercase tracking-widest italic">Awaiting Intelligence Feed...</p>
                </div>
              )}
            </div>
          </div>
        </section>

        <footer className="mt-24 text-center py-20 border-t border-white/10">
           <div className="flex flex-col items-center gap-8">
             <div className="flex items-center gap-6 text-white text-sm font-black uppercase tracking-[0.5em]">
                <div className="w-16 h-[1px] bg-emerald-500/30"></div>
                FINANALYTICS PRO ASSET
                <div className="w-16 h-[1px] bg-teal-500/30"></div>
             </div>
             <p className="text-white text-xs font-mono leading-relaxed font-bold">
               Engine: Gemini-3-Flash-Preview // Icons: Varied Green Accents // Scale: Enterprise
               <br/>
               © 2024 Strategic Intelligence Division. Confidential.
             </p>
             <div className="flex gap-6 mt-4">
                <i className="fa-solid fa-shield-halved text-emerald-500/40 text-xl"></i>
                <i className="fa-solid fa-fingerprint text-teal-500/40 text-xl"></i>
                <i className="fa-solid fa-microchip text-green-500/40 text-xl"></i>
             </div>
           </div>
        </footer>
      </main>
    </div>
  );
};

export default App;
