
import React from 'react';

interface SummaryCardProps {
  label: string;
  value: string;
  icon: string;
  colorClass: string; // Specific text color class like 'text-emerald-400'
}

const SummaryCard: React.FC<SummaryCardProps> = ({ label, value, icon, colorClass }) => {
  return (
    <div className="bg-[#1e293b] rounded-xl shadow-lg p-6 border border-white/10 transition-all hover:border-white/20">
      <div className="flex items-center justify-between mb-4">
        <span className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
          <i className={`fa-solid ${icon} text-xl ${colorClass}`}></i>
        </span>
      </div>
      <h3 className="text-white text-sm font-black uppercase tracking-widest">{label}</h3>
      <p className="text-3xl font-black text-white mt-1 tracking-tight">{value}</p>
    </div>
  );
};

export default SummaryCard;
